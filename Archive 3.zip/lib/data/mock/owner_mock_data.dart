import '../models/owner_models.dart';

class OwnerMockData {
  static final List<FarmerItemModel> farmers = [
    const FarmerItemModel(
      id: 'FARMER_001',
      name: 'মোঃ জহিরুল ইসলাম',
      phone: '01712-345678',
      region: 'সাভার, ঢাকা',
      farmType: 'সবজি চাষ',
      progressPercent: 80,
      isAssigned: true,
      landArea: 6.5,
      farmingCategories: ['সবজি', 'ধান'],
    ),
    const FarmerItemModel(
      id: 'FARMER_002',
      name: 'আবদুল করিম',
      phone: '01823-456789',
      region: 'ময়মনসিংহ',
      farmType: 'মাছ চাষ',
      progressPercent: 65,
      isAssigned: true,
      landArea: 4.2,
      farmingCategories: ['মাছ', 'ধান'],
    ),
    const FarmerItemModel(
      id: 'FARMER_003',
      name: 'রহিম উদ্দিন',
      phone: '01945-667788',
      region: 'চট্টগ্রাম',
      farmType: 'গরু পালন',
      progressPercent: 50,
      isAssigned: false,
      landArea: 3.8,
      farmingCategories: ['গরু'],
    ),
    const FarmerItemModel(
      id: 'FARMER_004',
      name: 'মোঃ সেলিম মিয়া',
      phone: '01678-990123',
      region: 'বরিশাল',
      farmType: 'সবজি চাষ',
      progressPercent: 90,
      isAssigned: true,
      landArea: 5.0,
      farmingCategories: ['সবজি', 'ধান', 'মাছ', 'গরু'],
    ),
    const FarmerItemModel(
      id: 'FARMER_005',
      name: 'কামাল হোসেন',
      phone: '01856-772211',
      region: 'খুলনা',
      farmType: 'মাছ চাষ',
      progressPercent: 75,
      isAssigned: true,
      landArea: 4.0,
      farmingCategories: ['মাছ', 'সবজি'],
    ),
    const FarmerItemModel(
      id: 'FARMER_006',
      name: 'মোঃ আল আমিন',
      phone: '01789-334455',
      region: 'রাজশাহী',
      farmType: 'শস্য চাষ',
      progressPercent: 40,
      isAssigned: false,
      landArea: 7.2,
      farmingCategories: ['ধান', 'গম'],
    ),
    const FarmerItemModel(
      id: 'FARMER_007',
      name: 'মোঃ হানিফ মিয়া',
      phone: '01322-998877',
      region: 'রংপুর',
      farmType: 'সবজি চাষ',
      progressPercent: 85,
      isAssigned: true,
      landArea: 3.5,
      farmingCategories: ['সবজি', 'ভুট্টা'],
    ),
  ];

  static final List<OwnerTaskPlanModel> plannedTasks = [
    const OwnerTaskPlanModel(
      id: 'PLAN_001',
      title: 'সবজি ক্ষেত পরিদর্শন',
      timeRange: 'সকাল ৮:০০ – ৯:০০',
      farmerName: 'রফিক উদ্দিন (চাষী)',
      location: 'উত্তর মাঠ, সবজি খামার',
      statusText: 'নির্ধারিত',

    ),
    const OwnerTaskPlanModel(
      id: 'PLAN_002',
      title: 'মাছের খাবার দেওয়া',
      timeRange: 'সকাল ১০:০০ – ১০:৩০',
      farmerName: 'করিম শেখ (চাষী)',
      location: 'দক্ষিণ পুকুর, মৎস্য খামার',
      statusText: 'নির্ধারিত',

    ),
    const OwnerTaskPlanModel(
      id: 'PLAN_003',
      title: 'গরুর খাবার দেওয়া',
      timeRange: 'দুপুর ১২:০০ – ১২:৩০',
      farmerName: 'আব্দুল জলিল (চাষী)',
      location: 'গরুর খামার, পশ্চিম মাঠ',
      statusText: 'চলমান',

    ),
    const OwnerTaskPlanModel(
      id: 'PLAN_004',
      title: 'বেগুন ক্ষেতে পানি দেওয়া',
      timeRange: 'বিকাল ৩:০০ – ৪:০০',
      farmerName: 'জাহানারা বেগম (চাষী)',
      location: 'পূর্ব মাঠ, বেগুন খামার',
      statusText: 'বাকি',

    ),
  ];

  static final List<FarmerActivityItemModel> selimActivities = [
    const FarmerActivityItemModel(
      id: 'ACT_001',
      title: 'সবজি ক্ষেত পরিদর্শন',
      description: 'টমেটো ও বেগুনের গাছের বৃদ্ধি পর্যবেক্ষণ করা হয়েছে। সব গাছ ভালো আছে।',
      time: 'সকাল ৮:৩০',
      location: 'সবজি ক্ষেত',

      statusText: 'সম্পন্ন',
    ),
    const FarmerActivityItemModel(
      id: 'ACT_002',
      title: 'কীটনাশক প্রয়োগ',
      description: 'বেগুন ক্ষেতে পোকার আক্রমণ প্রতিরোধে জৈব কীটনাশক স্প্রে করা হয়েছে।',
      time: 'সকাল ১০:১৫',
      location: 'বেগুন ক্ষেত',

      statusText: 'সম্পন্ন',
    ),
    const FarmerActivityItemModel(
      id: 'ACT_003',
      title: 'সার প্রয়োগ',
      description: 'ধান জমিতে ইউরিয়া সার প্রয়োগ করা হয়েছে।',
      time: 'দুপুর ১২:০০',
      location: 'ধান জমি',

      statusText: 'সম্পন্ন',
    ),
    const FarmerActivityItemModel(
      id: 'ACT_004',
      title: 'গরুকে খাবার প্রদান',
      description: 'গরুকে খড় ও সবুজ ঘাস খাওয়ানো হয়েছে এবং পানি দেওয়া হয়েছে।',
      time: 'দুপুর ২:৩০',
      location: 'গরুর খামার',

      statusText: 'সম্পন্ন',
    ),
    const FarmerActivityItemModel(
      id: 'ACT_005',
      title: 'পুকুর পরিদর্শন',
      description: 'পুকুরের পানির মান ও মাছের অবস্থা পরীক্ষা করা হয়েছে। পানি স্বচ্ছ আছে।',
      time: 'বিকাল ৪:০০',
      location: 'মাছের পুকুর',

      statusText: 'সম্পন্ন',
    ),
    const FarmerActivityItemModel(
      id: 'ACT_006',
      title: 'মাছকে খাবার প্রদান',
      description: 'পুকুরে মাছের জন্য নির্ধারিত খাবার প্রদান করা হয়েছে।',
      time: 'বিকাল ৫:৩০',
      location: 'মাছের পুকুর',

      statusText: 'সম্পন্ন',
    ),
  ];
}
